/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#define  TEMP_ADDR   (0x18)
#define  TEMP_REG    (0x5)
uint8 Readtemp(uint8 temp);
/* [] END OF FILE */
